package com.project.jonathanklevenproject;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

public class LoginActivity extends Fragment {

    private final String TAG = "LoginActivity";
    EditText userEmail;
    EditText userPassword;
    Button loginButton ;
    Button registerButton;

    private DBHandler_Login dbHandler;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View loginView = inflater.inflate(R.layout.fragment_login, container, false);

        //Initialize all the edit texts and buttons
        userEmail = loginView.findViewById(R.id.email_input);
        userPassword = loginView.findViewById(R.id.password_input);
        loginButton = loginView.findViewById(R.id.login_button);
        registerButton = loginView.findViewById(R.id.register_button);

        // [JK] Implementation example from:
        // https://www.geeksforgeeks.org/how-to-create-and-add-data-to-sqlite-database-in-android/

        //Create a new dbHandler for logging in
        dbHandler = new DBHandler_Login(this.getContext());

        // TODO Alternate style to clean up code below in comment:
        //findViewById(R.id.add_subject_button).setOnClickListener(view -> addSubjectClick());
        loginButton.setOnClickListener(view -> {

            //Get the info from the edit text fields
            String emailInput = userEmail.getText().toString();
            String passwordInput = userPassword.getText().toString();

            // Validate if fields are empty
            if (emailInput.isEmpty() && passwordInput.isEmpty()) {
                Toast.makeText(loginView.getContext(), "Please enter Login", Toast.LENGTH_SHORT).show();
                return;
            }

            if (dbHandler.verifyLogin(emailInput, passwordInput)) {
                Toast.makeText(loginView.getContext(), "Login SuccessFull", Toast.LENGTH_LONG).show();
                Navigation.findNavController(loginButton).navigate(R.id.navigation_weighttracker);
            }else {
                Toast.makeText(loginView.getContext(), "No Account, Please Register",
                        Toast.LENGTH_LONG).show();
            }
        });

        registerButton.setOnClickListener(view ->
                Navigation.findNavController(registerButton).navigate(R.id.navigation_register));


        return loginView;
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.d(TAG, "onStart");
    }
    @Override
    public void onStop() {
        super.onStop();
        Log.d(TAG, "onStop");
        ((AppCompatActivity)getActivity()).findViewById(R.id.nav_view).setVisibility(View.VISIBLE);

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy");
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d(TAG, "onPause");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "onResume");

        //Clear text
        userEmail.getText().clear();
        userPassword.getText().clear();
        ((AppCompatActivity)getActivity()).findViewById(R.id.nav_view).setVisibility(View.INVISIBLE);
    }
}
