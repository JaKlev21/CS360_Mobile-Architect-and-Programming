package com.project.jonathanklevenproject;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

public class SetGoalActivity extends Fragment {
    private EditText goalWeight;
    private Button setGoalButton;
    private Button updateGoalButton;
    private TextView currentGoal;

    private DBHandler_SetGoal dbHandler;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View setGoalView = inflater.inflate(R.layout.fragment_set_goal, container, false);

        //Initialize all the edit texts and buttons
        goalWeight = setGoalView.findViewById(R.id.set_goal_input);
        setGoalButton = setGoalView.findViewById(R.id.set_goal_button);
        currentGoal = setGoalView.findViewById(R.id.current_goal);
        updateGoalButton = setGoalView.findViewById(R.id.update_goal_button);

        //Instantiate new DATABASE!!!
        dbHandler = new DBHandler_SetGoal(this.getContext());

        // [JK] Change current goal TextView to value in database
        setGoalText();

        setGoalButton.setOnClickListener(view -> {

            //Get input fields data
            String goalInput = goalWeight.getText().toString();

            //Validate field is not empty
            if (goalInput.isEmpty()) {
                Toast.makeText(setGoalView.getContext(), "Please Enter a Goal Weight",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            //[JK] Verify Goal weight is already there if false add new goal weight - Like login
            if (dbHandler.verifyGoalExists()) {
                Toast.makeText(setGoalView.getContext(), "Goal already Set, Please Update",
                        Toast.LENGTH_LONG).show();
            } else {
                dbHandler.createGoal(goalInput);
                Toast.makeText(setGoalView.getContext(), "New Goal Added!",
                        Toast.LENGTH_SHORT).show();
                setGoalText();
            }
        });
        updateGoalButton.setOnClickListener(view -> {
            String updateValue = goalWeight.getText().toString();
            //Validate field is not empty
            if (updateValue.isEmpty()) {
                Toast.makeText(setGoalView.getContext(), "Please Enter an Update Weight",
                        Toast.LENGTH_SHORT).show();
            } else {
                dbHandler.updateGoal(1L, updateValue);
                Toast.makeText(setGoalView.getContext(), "New Goal Added!",
                        Toast.LENGTH_SHORT).show();
                setGoalText();
            }


        });

        return setGoalView;
    }
    @Override
    public void onResume() {
        goalWeight.setText("");
        super.onResume();
    }
    public void setGoalText() {
        if (dbHandler.getCurrentGoal().equals("")) {
            currentGoal.setText(getString(R.string.current_goal_text, getString(R.string.current_not_set)));
        }else {
            currentGoal.setText(getString(R.string.current_goal_text, dbHandler.getCurrentGoal()));
        }
    }
}