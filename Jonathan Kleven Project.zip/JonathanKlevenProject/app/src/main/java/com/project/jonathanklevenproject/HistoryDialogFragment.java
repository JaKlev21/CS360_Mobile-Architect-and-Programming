package com.project.jonathanklevenproject;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;
import androidx.annotation.Nullable;

public class HistoryDialogFragment extends DialogFragment {

    public interface OnWeightAddListener {
        void onWeightAdd(String date,
                         String weight);
    }

    private OnWeightAddListener mListener;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        final EditText dateEditText = new EditText(requireContext());
        final EditText weightEditText = new EditText(requireContext());

        dateEditText.setInputType(InputType.TYPE_CLASS_TEXT);
        dateEditText.setMaxLines(1);

        weightEditText.setInputType(InputType.TYPE_CLASS_TEXT);
        weightEditText.setMaxLines(1);

        return new AlertDialog.Builder(requireContext())
                .setTitle("Enter Weight: ")
                .setView(dateEditText)
                .setView(weightEditText)
                .setPositiveButton("Add New", (dialog, whichButton) -> {
                    String date = dateEditText.getText().toString();
                    String weight = weightEditText.getText().toString();
                    mListener.onWeightAdd(date.trim(), weight.trim());
                })
                .setNegativeButton("Cancel", null)
                .create();
    }
    public static String TAG = "WeightDialog";

    @Override
    public void onAttach(@NonNull Activity activity) {
        super.onAttach(activity);
        mListener = (OnWeightAddListener) activity;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


}
