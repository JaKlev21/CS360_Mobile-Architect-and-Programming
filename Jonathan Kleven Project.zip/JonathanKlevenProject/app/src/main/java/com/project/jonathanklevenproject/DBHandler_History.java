package com.project.jonathanklevenproject;

import android.content.ContentValues;
import static android.content.ContentValues.TAG;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHandler_History extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "historydb.db";
    private static final int VERSION = 1;

    public DBHandler_History(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class WeightHistoryTable {
        private static final String TABLE_NAME = "history";
//        private static final String COL_ID = "_id";
        private static final String COL_DATE = "date";
        private static final String COL_WEIGHT = "weight";

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + WeightHistoryTable.TABLE_NAME + " (" +
//                WeightHistoryTable.COL_ID + " integer primary key autoincrement, " +
                WeightHistoryTable.COL_DATE + " text, " +
                WeightHistoryTable.COL_WEIGHT + " text)");
    }

    public void createWeight(String date, String weight) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(WeightHistoryTable.COL_DATE, date);
        values.put(WeightHistoryTable.COL_WEIGHT, weight);

        db.insert(WeightHistoryTable.TABLE_NAME, null, values);

        db.close();

    }
    public boolean deleteWeight(long id) {
        SQLiteDatabase db = getWritableDatabase();
        int rowsDeleted = db.delete(WeightHistoryTable.TABLE_NAME, WeightHistoryTable.COL_DATE + " = ?",
                new String[] {Long.toString(id) });
        return rowsDeleted > 0;
    }

    public boolean updateWeight(long id, String date, String weight) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(WeightHistoryTable.COL_DATE, date);
        values.put(WeightHistoryTable.COL_WEIGHT, weight);

        int rowsUpdated = db.update(WeightHistoryTable.TABLE_NAME, values, "_id = ? ",
                new String[] {Long.toString(id) });
        return rowsUpdated > 0;
    }

    public void readWeight() {
        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from " + WeightHistoryTable.TABLE_NAME;
        Cursor cursor = db.rawQuery(sql, null);

        if (cursor.getCount() != 0) {
            cursor.moveToFirst();

            do {
                long id = cursor.getLong(0);
                String date = cursor.getString(1);
                String weight = cursor.getString(2);
                Log.d(TAG, "Weight History = " + id + " ," + date + " ," + weight);
            } while (cursor.moveToNext());

        }
        cursor.close();
    }

    public Cursor getData() {
        SQLiteDatabase db = this.getWritableDatabase();
        String sql = "select * from " + WeightHistoryTable.TABLE_NAME;

        return db.rawQuery(sql, null);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + WeightHistoryTable.TABLE_NAME);
        onCreate(db);
    }
}