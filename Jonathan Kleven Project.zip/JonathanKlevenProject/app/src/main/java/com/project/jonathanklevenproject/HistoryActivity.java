package com.project.jonathanklevenproject;

import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class HistoryActivity extends Fragment
        implements HistoryDialogFragment.OnWeightAddListener {
    private final String TAG = "HistoryFragment";

    RecyclerView recyclerView;
    private ArrayList<String> date, weight;
    private DBHandler_History dbHandler;
    WeightAdapter adapter;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View historyView = inflater.inflate(R.layout.fragment_history,
                container, false);

        //Create new dbHandler for History DataBase
        dbHandler = new DBHandler_History(this.getContext());

        date = new ArrayList<>();
        weight = new ArrayList<>();

        recyclerView = historyView.findViewById(R.id.history_recycler_view);
        adapter = new WeightAdapter(date, weight);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new GridLayoutManager(this.getContext(), 3));
        displaydata();


        //TODO long press to edit or delete history items
        //TODO color code history cards
        return historyView;
    }

    private void displaydata() {
        Cursor cursor = dbHandler.getData();
        if (cursor.getCount() == 0) {
            Toast.makeText(this.getContext(), "No Data In Database",
                    Toast.LENGTH_SHORT).show();
        }
        else {
            while (cursor.moveToNext()) {
                date.add(cursor.getString(0));
                weight.add(cursor.getString(1));
            }
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.d(TAG, "onStart");
    }
    @Override
    public void onStop() {
        super.onStop();
        Log.d(TAG, "onStop");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy");
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d(TAG, "onPause");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "onResume");
    }


    @Override
    public void onWeightAdd(String date, String weight) {

    }

    public class WeightAdapter extends RecyclerView.Adapter<WeightHolder> {
        private final ArrayList date_id, weight_id;

        //[JK] Removed Context context from prams
        public WeightAdapter(ArrayList date_id, ArrayList weight_id) {
//            this.context = context;
            this.date_id = date_id;
            this.weight_id = weight_id;
        }

        @NonNull
        @Override
        public WeightHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//            View v = LayoutInflater.from(context).inflate(R.layout.recycler_view_items, parent, false);
            LayoutInflater layoutInflater = LayoutInflater.from(getActivity());
            return new WeightHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(@NonNull WeightHolder holder, int position) {
            holder.date_id.setText(String.valueOf(date_id.get(position)));
            holder.weight_id.setText(getString(R.string.history_lbs, String.valueOf(weight_id.get(position))));

//            holder.bind();
        }

        @Override
        public int getItemCount() {
            return date_id.size();
        }
    }

    public static class WeightHolder extends RecyclerView.ViewHolder {
        TextView date_id;
        TextView weight_id;

        public WeightHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.recycler_view_items, parent, false));
            date_id = itemView.findViewById(R.id.date_text_view);
            weight_id = itemView.findViewById(R.id.weight_text_view);
        }

    }
}