package com.project.jonathanklevenproject;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

public class TrackerActivity extends Fragment {

    private final String TAG = "TrackerActivity";

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        DBHandler_History dbHandler;

        View trackerView = inflater.inflate(R.layout.fragment_log_weight,
                container, false);

        EditText dateInput = trackerView.findViewById(R.id.date_input);
        EditText weightInput = trackerView.findViewById(R.id.weight_input);
        Button addData = trackerView.findViewById(R.id.add_data_button);

        //Create a new DBHandler for adding weight
        dbHandler = new DBHandler_History(this.getContext());

        addData.setOnClickListener(view -> {
            String date = dateInput.getText().toString();
            String weight = weightInput.getText().toString();

            if (date.isEmpty() && weight.isEmpty()) {
                Toast.makeText(trackerView.getContext(),
                        "Please enter Date and Weight", Toast.LENGTH_SHORT).show();
                return;
            }
            else {
                dbHandler.createWeight(date, weight);
                Toast.makeText(trackerView.getContext(),
                        "New Weight Added!", Toast.LENGTH_SHORT).show();
                dateInput.getText().clear();
                weightInput.getText().clear();
            }
        });

        return trackerView;
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.d(TAG, "onStart");
    }
    @Override
    public void onStop() {
        super.onStop();
        Log.d(TAG, "onStop");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy");
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d(TAG, "onPause");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "onResume");
    }
}