package com.project.jonathanklevenproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHandler_SetGoal extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "setgoaldb.db";
    private static final int VERSION = 1;

    public DBHandler_SetGoal(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class SetGoalTable {
        private static final String TABLE_NAME = "SetGoal";
        private static final String COL_ID = "_id";
        private static final String COL_GOAL = "weight";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + SetGoalTable.TABLE_NAME + " (" +
                SetGoalTable.COL_ID + " integer primary key autoincrement, " +
                SetGoalTable.COL_GOAL + " text)");
    }

    public void createGoal(String weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(SetGoalTable.COL_GOAL, weight);

        db.insert(SetGoalTable.TABLE_NAME, null, values);

        db.close();
    }

    public void updateGoal(Long id, String weight) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(SetGoalTable.COL_GOAL, weight);

        int rows_updated = db.update(SetGoalTable.TABLE_NAME, values, "_id = ?",
                new String[] {Long.toString(id) });
    }

    public boolean verifyGoalExists() {
        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from " + SetGoalTable.TABLE_NAME;
        Cursor cursor = db.rawQuery(sql, null);
        //cursor.moveToFirst();
        if (cursor.moveToFirst()) {
            cursor.close();
            return true;
        }else{
            cursor.close();
            return false;
        }
    }
    public String getCurrentGoal() {
        String goalnum = "";
        SQLiteDatabase db = getReadableDatabase();
        String sql = "select * from " + SetGoalTable.TABLE_NAME;
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            String goalwt = cursor.getString(1);
            goalnum = goalwt;
        }
        cursor.close();
        return goalnum;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + DBHandler_SetGoal.SetGoalTable.TABLE_NAME);
        onCreate(db);

    }
}
