package com.project.jonathanklevenproject;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

public class RegisterActivity extends Fragment {

    private final String TAG = "RegisterActivity";

    private DBHandler_Login dbHandler;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View registerView = inflater.inflate(R.layout.fragment_register, container, false);

        //Initialize the edit text fields and one button
        EditText userEmail = registerView.findViewById(R.id.register_email);
        EditText userPassword = registerView.findViewById(R.id.register_password);
        Button registerAccountButton = registerView.findViewById(R.id.register_account_button);
        TextView backLogin = registerView.findViewById(R.id.back_to_login);

        //Create a new dbHandler for logging in
        dbHandler = new DBHandler_Login(this.getContext());

        registerAccountButton.setOnClickListener(view -> {
            //Get the info from the edit text fields
            String emailInput = userEmail.getText().toString();
            String passwordInput = userPassword.getText().toString();

            // Validate if fields are empty
            if (emailInput.isEmpty() && passwordInput.isEmpty()) {
                Toast.makeText(registerView.getContext(), "Please enter Login", Toast.LENGTH_SHORT).show();
                return;
            }

            if (dbHandler.verifyLogin(emailInput, passwordInput)) {
                Toast.makeText(registerView.getContext(), "Account Already Exists", Toast.LENGTH_LONG).show();
            }else {
                dbHandler.addNewLogin(emailInput, passwordInput);
                Toast.makeText(registerView.getContext(), "Congratulations! Account Created", Toast.LENGTH_LONG).show();
                Navigation.findNavController(registerAccountButton).navigate(R.id.navigation_login);
            }

        });

        backLogin.setOnClickListener( view -> {
            Navigation.findNavController(backLogin).navigate(R.id.navigation_login);
        });

        return registerView;
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.d(TAG, "onStart");
    }
    @Override
    public void onStop() {
        super.onStop();
        Log.d(TAG, "onStop");
        ((AppCompatActivity)getActivity()).findViewById(R.id.nav_view).setVisibility(View.VISIBLE);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy");
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d(TAG, "onPause");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(TAG, "onResume");
        ((AppCompatActivity)getActivity()).findViewById(R.id.nav_view).setVisibility(View.INVISIBLE);
    }
}