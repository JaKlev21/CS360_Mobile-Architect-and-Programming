package com.project.jonathanklevenproject;

import android.content.ContentValues;
import static android.content.ContentValues.TAG;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DBHandler_Login extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "logindb.db";
    private static final int VERSION = 1;

    public DBHandler_Login(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class LoginTable {
        private static final String TABLE_NAME = "login";
        private static final String COL_ID = "_id";
        private static final String COL_EMAIL = "email";
        private static final String COL_PASSWORD = "password";

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + LoginTable.TABLE_NAME + " (" +
                LoginTable.COL_ID + " integer primary key autoincrement, " +
                LoginTable.COL_EMAIL + " text, " +
                LoginTable.COL_PASSWORD + " text)");
    }

    public void addNewLogin(String email, String password) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(LoginTable.COL_EMAIL, email);
        values.put(LoginTable.COL_PASSWORD, password);

        db.insert(LoginTable.TABLE_NAME, null, values);

        db.close();

    }

    public boolean verifyLogin(String loginemail, String loginpassword) {

        SQLiteDatabase db = getReadableDatabase();

        // [JK] SQL string must match the fields its searching!!
        //TODO Use the loginpassword variable
        String sql = "select * from " + LoginTable.TABLE_NAME + " where email = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { loginemail });
        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(0);
                String email = cursor.getString(1);
                String password = cursor.getString(2);
                Log.d(TAG, "Login Account = " + id + ", " + email + ", " + password);
                return true;
            } while (cursor.moveToNext());
        }
        cursor.close();
        return false;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion,
                          int newVersion) {
        db.execSQL("drop table if exists " + LoginTable.TABLE_NAME);
        onCreate(db);
    }
}